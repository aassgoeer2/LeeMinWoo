#pragma once
#include "Deque.h"
#include <stdlib.h>
#include <stdio.h>

typedef int Data;

typedef struct _node
{
	Data data;
	struct _node * next;
	struct _node * prev;
} Node;

typedef struct _dlDeque
{
	Node * head;
	Node * tail;
} DLDeque;

typedef DLDeque Deque;
typedef DLDeque Queue;

void QueueInit(Queue * que);
int QueIsEmpty(Queue * que);


int DQIsEmpty(Deque * pdeq);

void DQAddLast(Deque * pdeq, Data data);
Data DQRemoveFirst(Deque * pdeq);
Data DQGetFirst(Deque * pdeq);